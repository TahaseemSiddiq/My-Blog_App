import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaUser, FaMicroblog } from "react-icons/fa";
import {
  AppBar,
  Toolbar,
  Button,
  Typography,
  Tabs,
  Tab,
  Box,
  TextField,
  InputAdornment,
} from "@mui/material";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { authActions } from "../redux/store";
import toast from "react-hot-toast";
import SearchIcon from "@mui/icons-material/Search";

const Header = () => {
  const isLogin = useSelector((state) => state.isLogin) || localStorage.getItem("userId");
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [value, setValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");

  const handleLogout = () => {
    try {
      dispatch(authActions.logout());
      toast.success("Logout Successfully");
      navigate("/login");
      localStorage.clear();
    } catch (error) {
      console.log(error);
    }
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      navigate(`/search?query=${searchQuery}`);
    }
  };

  return (
    <AppBar position="sticky" sx={{ backgroundColor: "#8bc34a" }}>
      <Toolbar sx={{ flexDirection: { xs: "column", md: "row" } }}>
        <Typography
          variant="h6"
          component="div"
          sx={{
            flexGrow: 1,
            display: "flex",
            alignItems: "center",
            mb: { xs: 1, md: 0 },
          }}
        >
          <FaMicroblog style={{ marginRight: "8px" }} />
          My BlogApp
        </Typography>
        {isLogin && (
          <>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                mb: { xs: 1, md: 0 },
                width: { xs: "100%", md: "auto" },
              }}
            >
              <TextField
  variant="outlined"
  placeholder="Search Blogs"
  value={searchQuery}
  onChange={(e) => setSearchQuery(e.target.value)}
  onKeyPress={(e) => {
    if (e.key === "Enter") handleSearch();
  }}
  sx={{
    backgroundColor: "white",
    ml: { xs: 0, md: 2 },
    height: { xs: 55, md: 48 }, // Adjust height for smaller devices
    width: { xs: "60%", md: "auto" }, // Adjust width for smaller devices
    borderRadius: 0, // Ensure consistent border radius
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderColor: "#ccc", // Adjust border color here
      },
    },
  }}
  InputProps={{
    startAdornment: (
      <InputAdornment position="start">
        <SearchIcon />
      </InputAdornment>
    ),
  }}
/>

              <Button
                onClick={handleSearch}
                variant="contained"
                sx={{
                  ml: { xs: 1, md: 2 },
                  backgroundColor: "#ffffff",
                  color: "#8bc34a",
                  height: { xs: 55, md: 48 }, // Match height with TextField
                  width: { xs: "40%", md: "auto" }, // Adjust width for smaller devices
                }}
              >
                Search
              </Button>
            </Box>
            <Tabs
              value={value}
              onChange={(e, val) => setValue(val)}
              textColor="inherit"
              sx={{
                flexGrow: 1,
                display: "flex",
                justifyContent: { xs: "center", md: "flex-start" },
                mb: { xs: 1, md: 0 },
              }}
            >
              <Tab label="Blogs" component={Link} to="/blogs" />
              <Tab label="My Blogs" component={Link} to="/my-blogs" />
              <Tab label="Create Blog" component={Link} to="/create-blog" />
            </Tabs>
          </>
        )}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: { xs: "center", md: "flex-end" },
          }}
        >
          {!isLogin ? (
            <>
              <Button
                component={Link}
                to="/login"
                variant="outlined"
                sx={{
                  color: "white",
                  borderColor: "white",
                  margin: "0 8px",
                }}
              >
                Login
              </Button>
              <Button
                component={Link}
                to="/register"
                variant="outlined"
                sx={{
                  color: "white",
                  borderColor: "white",
                  margin: "0 8px",
                }}
              >
                Register
              </Button>
            </>
          ) : (
            <Button
              onClick={handleLogout}
              variant="outlined"
              sx={{ color: "white", borderColor: "white" }}
            >
              <FaUser style={{ marginRight: "8px" }} />
              Logout
            </Button>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
